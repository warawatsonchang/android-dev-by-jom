/** Automatically generated file. DO NOT MODIFY */
package it.gmariotti.cardslib.library;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}